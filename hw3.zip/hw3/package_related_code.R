
library(tidyverse)
est <- read_csv("data/est.csv", show_col_types = FALSE)%>%
  rename(year= Year)


dat <- read_csv("data/contraceptive_use.csv",show_col_types = FALSE)%>%
  rename(iso = division_numeric_code) %>%
  mutate(
    year = as.double((start_date + end_date) / 2),
    cp = contraceptive_use_modern * 100
  )


library(devtools)
load_all("../hw3")


document("../hw3")


get_width_ci(est, iso_code = 4, coverage = 95)
get_width_ci(est, iso_code = 4, coverage = 80)
plot_cp(dat %>% select(-iso), est, iso_code = 4)
plot_cp(dat %>% select(-year), est, iso_code = 4)
plot_cp(dat %>% select(-cp), est, iso_code = 4)
plot_cp(dat, est=est %>% select(-iso), iso_code = 4)

dat_bug <- dat %>%
  mutate(cp = FALSE)
plot_cp(dat_bug, est, iso_code = 4)

plot_cp(dat, est, iso_code = 4, CI = 99)



