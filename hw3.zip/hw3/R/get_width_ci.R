
#' calculate the widths of the uncertainty intervals
#' @param est dataset
#' @param iso_code country code
#' @param coverage confidence interval
#'
#' @return year and interval value
#' @export
get_width_ci <- function(est=est, iso_code, coverage) {

  est1<-est%>%
    filter(iso == iso_code)

  # Calculate interval width based on coverage
  if (coverage == 95) {
    interval_width <- est1$U95 - est1$L95
  }
  else if (coverage == 80) {
    interval_width <- est1$U80 - est1$L80
  }

  # Create a data frame with the results
  result <- data.frame(
    year = est1$year,
    width = interval_width
  )

  return(result)
}

