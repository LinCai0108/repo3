
#' plot_cp add error message
#'
#' @param dat dataset1
#' @param est dataset2
#' @param iso_code country code
#' @param CI confidence interval
#'
#' @return error message
#' @export
plot_cp <- function(dat=dat, est=est, iso_code, CI = 95) {
  # Define required columns for dataset
  required_cols_dat <- c("iso", "year", "cp")

  # Check for missing columns in 'dat'
  missing_cols_dat <- setdiff(required_cols_dat, names(dat))
  if (length(missing_cols_dat) > 0) {
    if ("iso" %in% missing_cols_dat) {
      stop("Input data file dat and estimates file est must contain variable iso.")
    } else if ("year" %in% missing_cols_dat || "cp" %in% missing_cols_dat) {
      stop("Input data file dat must contain variable year and cp.")
    }
  }

  # Check for missing columns in 'est'
  required_cols_est <- c("iso", "year")
  missing_cols_est <- setdiff(required_cols_est, names(est))
  if (length(missing_cols_est) > 0) {
    if ("iso" %in% missing_cols_est) {
      stop("Input data file dat and estimates file est must contain variable iso.")
    }
  }

  # Check if CI is valid
  if (!is.na(CI) && !CI %in% c(80, 95, NA)) {
    stop("CI must be 80, 95, or NA.")
  }

  # Check if cp is numeric in dat_bug
  if (!is.numeric(dat_bug$cp)) {
    stop("Input cp in data file dat must be numeric.")
  }

  est01 <- est %>%
    filter(iso==iso_code,!is.na(year), !is.na(Median))
  dat01 <- dat %>%
    filter(iso==iso_code,!is.na(year), !is.na(cp))

  plot <- ggplot() +
    geom_line(data = est01, aes(x = year, y = Median)) +
    geom_point(data = dat01, aes(x = year, y = cp)) +
    labs(x = "Time", y = "Modern use (%)",
         title = est01$`Country or area`[1])

  if (!is.na(CI) && CI == 80) {
    plot <- plot + geom_smooth(data = est01, stat = "identity",
                               aes(x = year, y = Median, ymin = L80, ymax = U80))
  } else if (!is.na(CI) && CI == 95) {
    plot <- plot + geom_smooth(data = est01, stat = "identity",
                               aes(x = year, y = Median, ymin = L95, ymax = U95))
  }
  else if (is.na(CI)) {
    plot <- plot
  }
  print(plot)
}










