# Load necessary libraries
library(dplyr)
library(testthat)

# Create the data frame with random values
set.seed(123)
est <- data.frame(
  iso = rep(1:5, each = 10),
  year = rep(1990:2005, length.out = 50),
  U95 = runif(50, 20, 50),
  L95 = runif(50, 10, 20),
  U80 = runif(50, 15, 40),
  L80 = runif(50, 5, 15)
)


library(testthat)

iso_code <- 4
iso <- iso_code
est_01 <- data.frame(iso, year = 2000, U95 = NA, L95 = 10)
est_02 <- data.frame(iso, year = 2000, U95 = 50, L95 = NA)

# test
test_that("NA handling works", {
  # Test that get_width_ci returns NA when U95 is NA
  result_u95 <- get_width_ci(est_01, iso_code, coverage = 95)
  expect_true(is.na(result_u95$width))

  # Test that get_width_ci returns NA when L95 is NA
  result_l95 <- get_width_ci(est_02, iso_code, coverage = 95)
  expect_true(is.na(result_l95$width))
})

