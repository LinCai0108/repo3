
# Load necessary libraries
library(dplyr)
library(testthat)

# Create the data frame with random values
set.seed(123)
est <- data.frame(
  iso = rep(1:5, each = 10),
  year = rep(1990:2005, length.out = 50),
  U95 = runif(50, 20, 50),
  L95 = runif(50, 10, 20),
  U80 = runif(50, 15, 40),
  L80 = runif(50, 5, 15)
)
iso_code <- 4

# Unit test
test_that("returns correct width 95 interval", {
  expected <- est %>%
    filter(iso == iso_code) %>%
    mutate(width = U95 - L95)

  expect_equal(get_width_ci(est, iso_code, coverage = 95)$width,expected$width)
})
